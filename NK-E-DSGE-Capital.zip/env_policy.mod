// Authors: B. Annicchiarico and  F. Di Dio

// Scenarios to run: CT (Carbon Tax) and CAT (Cap-and-Trade)

// Set to 1 for CT and to 0 for CAT

@#define CT=1     

    @#if CT == 1
        @#define scenario_name = "Carbon Tax"
    @#else
        @#define scenario_name = "Cap-and-Trade"
    @#endif

    // Display current scenario
    disp("Running scenario: @{scenario_name}");

// Endogenous variables
var A // TFP
C   // Consumption
CA  // Abatement cost
DP  // Price dispersion
G   // Public spending 
I   // Investments
K   // Capital 
L   // Labor
M   // Pollution stock 
MC  // Real marginal cost
P_STAR // New price - Calvo pricing scheme 
PZ   // Price of carbon 
R    // Nominal interest rate 
RK   // Return on capital 
T    // Lump-sum taxes 
U    // Abatement effort
W    // Wage
X    // Variable -  Calvo pricing scheme
Y    // Output
Z    // Emissions 
ETA  // Monetary policy shock 
THETA // Variable -  Calvo pricing scheme 
LAMBDA // MU of consumption 
PAI   // Infaltion 
PSI   // Marginal cost to manufacture the good
OMEGA // Variable -  Calvo pricing scheme
Q    // Tobin's Q
real_r // Real interest rate 
WELF;  // Welfare 

// Exogenous variables 
varexo epsilon_A epsilon_G epsilon_ETA;

// Parameters and steady state values
parameters ALPHA BET GAMMA_I DELTA_K DELTA_M THETA_P XI_P MU_L PHI PHI1 PHI2 iota_PAI VARPHI A_SS G_SS ETA_SS RHO_A RHO_G RHO_ETA Z_SS_T CARBON_TAX R_SS Y_SS Z_STAR_SS GAMMA0 GAMMA1 GAMMA2;

// Parametrization and stead-state restrictions
PAI_SS=1; 
iota_PAI=3; 
THETA_P=6;
DELTA_K=0.025;
ALPHA=1/3;
PHI=1;
BET=0.99;
XI_P=3/4;
VARPHI=0.45; 
GAMMA_I=15;
DELTA_M=1-0.9979;
PHI2=2.8;
GAMMA2= 1.464700000000000e-008;
GAMMA1=-6.672200000000000e-006;
GAMMA0=1.3950e-3;
US_SHARE=0.20840121;
A_SS=1.248007701187076;
MU_L=19.841269841269842;
ETA_SS=1;
RK_SS=1/BET-(1-DELTA_K);
Q_SS=1;
P_STAR_SS=1;
DP_SS=1; //price dispersion is 1 in steady state since there's no trend inflation 
MC_SS=(THETA_P-1)/THETA_P;
R_SS=BET^(-1);
real_r_SS=R_SS/PAI_SS
G_SS=0.079482322394245;
Z_STAR_SS=1.329885967199994;
Z_SS=0.350114032773276;
ETA_SS=1;
Z_SS_T=Z_SS*(1-0.2); 
M_SS=(Z_SS_T+Z_STAR_SS)/DELTA_M;
PHI2=2.8;
PHI1=0.18;

// Steady-state values for U, K, PSI and L 
// Initial conditions
ss0_ini=[0.2 0.7 0.8 6 0.8];
options = optimset('Display','iter','TolX',1e-6);
[ss,fval,exitflag]=fsolve(@ss_policy,ss0_ini,options, RK_SS,MC_SS,G_SS,DELTA_K,ALPHA,PHI,MU_L,A_SS,VARPHI, GAMMA0, GAMMA1, GAMMA2,PHI2,PHI1,Z_SS_T,M_SS);

f=ss';
L_SS=ss(1);
Y_SS=ss(2);
PSI_SS=ss(3);
K_SS=ss(4);
U_SS=ss(5);

// Other implied steady-state values
I_SS=DELTA_K*K_SS;
CA_SS=(PHI1*U_SS^PHI2)*Y_SS; //abatement cost
PZ_SS=(PHI1*PHI2*U_SS^(PHI2-1))/VARPHI; //permt price (or tax)
C_SS=Y_SS-DELTA_K*K_SS-G_SS-CA_SS;
X_SS=(PSI_SS/(1-XI_P*BET))*Y_SS/C_SS;
THETA_SS=(1/(1-XI_P*BET))*Y_SS/C_SS;
LAMBDA_SS=C_SS^(-1);
W_SS=(MU_L*L_SS^PHI)/LAMBDA_SS; 
OMEGA_SS=(1/(1-XI_P*BET))*(PHI1*U_SS^PHI2+PZ_SS*(1-U_SS)*VARPHI)*Y_SS/C_SS;
WELF_SS=((1-BET)^(-1))*(log(C_SS)-MU_L*(L_SS^(1+PHI))/(1+PHI));
real_r_SS=R_SS-PAI_SS;
CARBON_TAX=PZ_SS;
T_SS=G_SS-PZ_SS*Z_SS_T;

// shocks relates parameters
RHO_A=0.95; 
SIGMA_A =0.01;
RHO_G=0.97;
SIGMA_G=0.01;
RHO_ETA=0.15;
SIGMA_ETA=0.01;


model;

//Eq. 1 MU of consumption 
[name = 'MU of consumption']
LAMBDA=C^(-1);

//Eq.2 Euler equation
[name='Euler equation']
C^(-1)=BET*(R/PAI(+1))*(C(+1))^(-1);

//Eq. 3 Labor supply
[name = 'Labor supply']
W=MU_L*(L^PHI)/LAMBDA;

//Eq.4 Capital Euler equation equation
[name = 'Capital Euler equation']
BET*(RK(+1)+GAMMA_I*(I(+1)/K-DELTA_K)*(I(+1)/K)^2)-Q*LAMBDA/LAMBDA(+1)+BET*(1-DELTA_K)*Q(+1)=0;

//Eq.5 Tobin Q
[name = 'Tobin Q']
-1+Q-GAMMA_I*(I/K(-1)-DELTA_K)*(I/K(-1))-(GAMMA_I/2)*(I/(K(-1))-DELTA_K)^2=0;

// Eq. 6 Resource constraint
[name = 'Resource constraint']
Y=C+I+G+CA+(GAMMA_I/2)*(((I/K(-1)-DELTA_K)^2))*I;

// Eq. 7 Capital accumulation
[name = 'Capital accumulation']
K=I+(1-DELTA_K)*K(-1);

// Eq. 8 Production function with damage function
[name = 'Production function']
Y=(1-GAMMA0-GAMMA1*M-GAMMA2*M^2)*(DP^(-1))*A*(K(-1))^ALPHA*L^(1-ALPHA);

//Eq. 9 Labor demand
[name = 'Labor demand']
W=(1-ALPHA)*PSI*Y/L;

//Eq. 10 Capital demand
[name = 'Capital demand']
RK=ALPHA*PSI*Y/K(-1);

//Eq. 11 Abatement level
[name = 'Optimal abatenment']
PZ=(VARPHI)^(-1)*PHI1*PHI2*U^(PHI2-1);

// Eq. 12 Price equation 1/6
[name = 'Calvo price equation 1/6']
P_STAR=(THETA_P/(THETA_P-1))*((X+OMEGA)/THETA);

// Eq. 13 Price equation 2/6
[name = 'Calvo price equation 2/6']
X=LAMBDA*PSI*Y+XI_P*BET*X(+1)*(PAI(+1))^THETA_P;

// Eq. 14 Price equation 3/6
[name = 'Calvo price equation 3/6']
THETA=LAMBDA*Y+XI_P*BET*THETA(+1)*(PAI(+1))^(THETA_P-1);

// Eq. 15 Price equation 4/6
[name = 'Calvo price equation 4/6']
OMEGA=LAMBDA*(PHI1*U^PHI2+PZ*(1-U)*VARPHI)*Y+XI_P*BET*((PAI(+1))^THETA_P)*OMEGA(+1);

// Eq. 16 Price equation 5/6
[name = 'Calvo price equation 5/6']
1=XI_P*(PAI)^(THETA_P-1)+(1-XI_P)*P_STAR^(1-THETA_P);

// Eq. 17 Price equation 6/6
[name = 'Calvo price equation 6/6']
DP=(1-XI_P)*P_STAR^(-THETA_P)+XI_P*((PAI)^THETA_P)*DP(-1);

// Eq. 18 Marginal cost
[name = 'Marginal cost']
MC=PSI+PHI1*U^PHI2+PZ*(1-U)*VARPHI;

// Eq. 19 Emission 
[name = 'Emissions']
Z=VARPHI*Y*(1-U)*DP;

// Eq. 20 Pollution stock
[name = 'Pollution stock']
M=Z+(1-DELTA_M)*M(-1)+Z_STAR_SS;

// Eq. 21 Abatement cost
[name = 'Abatement cost']
CA=(PHI1*U^PHI2)*Y*DP;

// Eq. 22 Government budget constraint
[name = 'Government budget constraint']
T=G-PZ*Z;

//Eq. 23 Monetary rule
[name = 'Simple Taylor Rule']
log(R/R_SS)=iota_PAI*log(PAI)+log(ETA);

// Eq. 24 Technology
[name = 'TFP AR(1)']
log(A)=(1-RHO_A)*log(A_SS)+RHO_A*log(A(-1))+epsilon_A;

// Eq. 25 Public spending
[name = 'Public spending AR(1)']
log(G)=(1-RHO_G)*log(G_SS)+RHO_G*log(G(-1))+epsilon_G;

// Eq. 26 Monetary shock
[name = 'Monetary policy AR(1)']
log(ETA)=(1-RHO_ETA)*log(ETA_SS)+RHO_ETA*log(ETA(-1))+epsilon_ETA;

// Eq. 27 Environmental policy regime CT v. CAT
@#if CT==1 
[name = 'Carbon tax']
PZ=CARBON_TAX;
@#else
[name = 'Cap-and-trade']
 Z=Z_SS_T;
@#endif


// Eq.28 Real interest rate
[name = 'Fisher equation']
real_r=R-PAI(+1); 

// Eq. 29 Welfare
[name = 'Welfare']
WELF=(log(C)-MU_L*(L^(1+PHI))/(1+PHI))+BET*WELF(+1);

end;

initval;
A=A_SS; 
C=C_SS; 
CA=CA_SS;
DP=DP_SS; 
G=G_SS;
I=I_SS; 
K=K_SS; 
L=L_SS;
M=M_SS;
MC=MC_SS; 
P_STAR=P_STAR_SS; 
PZ=PZ_SS; 
R=R_SS;
RK=RK_SS; 
T=T_SS;
U=U_SS;
W=W_SS;
X=X_SS; 
Y=Y_SS; 
Z=Z_SS_T;
ETA=ETA_SS;
THETA=THETA_SS;
LAMBDA=LAMBDA_SS; 
PAI=PAI_SS; 
PSI=PSI_SS;
OMEGA=OMEGA_SS;
Q=Q_SS;
real_r=real_r_SS;

end;



steady;
resid(1);
check;


shocks;
var epsilon_A=SIGMA_A^2;
var epsilon_G=SIGMA_G^2;
var epsilon_ETA=SIGMA_ETA^2;
end; 

stoch_simul(order=1,irf=21,nograph); 




//save results
@#if CT==1
ct_epsilon_A=[];
ct_epsilon_G=[];
ct_epsilon_ETA=[];

ct_epsilon_A(1,:)=(A_epsilon_A/A_SS)*100;
ct_epsilon_A(2,:)=(C_epsilon_A/C_SS)*100;
ct_epsilon_A(3,:)=(G_epsilon_A/G_SS)*100;
ct_epsilon_A(4,:)=(I_epsilon_A/I_SS)*100;
ct_epsilon_A(5,:)=(K_epsilon_A/K_SS)*100;
ct_epsilon_A(6,:)=(L_epsilon_A/L_SS)*100;
ct_epsilon_A(7,:)=(M_epsilon_A/M_SS)*100;
ct_epsilon_A(8,:)=(R_epsilon_A)*.400;
ct_epsilon_A(9,:)=(W_epsilon_A/W_SS)*100;
ct_epsilon_A(10,:)=(Y_epsilon_A/Y_SS)*100;
ct_epsilon_A(11,:)=(Z_epsilon_A/Z_SS)*100;
ct_epsilon_A(12,:)=(PAI_epsilon_A)*.400;
ct_epsilon_A(13,:)=(ETA_epsilon_A)*.100;
ct_epsilon_A(14,:)=(PSI_epsilon_A/PSI_SS)*100;
ct_epsilon_A(15,:)=(W_epsilon_A/W_SS)*100;
ct_epsilon_A(16,:)=(real_r_epsilon_A)*400;
ct_epsilon_A(17,:)=(MC_epsilon_A/MC_SS)*100;
ct_epsilon_A(18,:)=(PZ_epsilon_A/PZ_SS)*100;
ct_epsilon_A(19,:)=(U_epsilon_A/U_SS)*100;
ct_epsilon_A(20,:)=(CA_epsilon_A/CA_SS)*100;


ct_epsilon_G(1,:)=(A_epsilon_G/A_SS)*100;
ct_epsilon_G(2,:)=(C_epsilon_G/C_SS)*100;
ct_epsilon_G(3,:)=(G_epsilon_G/G_SS)*100;
ct_epsilon_G(4,:)=(I_epsilon_G/I_SS)*100;
ct_epsilon_G(5,:)=(K_epsilon_G/K_SS)*100;
ct_epsilon_G(6,:)=(L_epsilon_G/L_SS)*100;
ct_epsilon_G(7,:)=(M_epsilon_G/M_SS)*100;
ct_epsilon_G(8,:)=(R_epsilon_G)*.400;
ct_epsilon_G(9,:)=(W_epsilon_G/W_SS)*100;
ct_epsilon_G(10,:)=(Y_epsilon_G/Y_SS)*100;
ct_epsilon_G(11,:)=(Z_epsilon_G/Z_SS)*100;
ct_epsilon_G(12,:)=(PAI_epsilon_G)*.400;
ct_epsilon_G(13,:)=(ETA_epsilon_G)*.100;
ct_epsilon_G(14,:)=(PSI_epsilon_G/PSI_SS)*100;
ct_epsilon_G(15,:)=(W_epsilon_G/W_SS)*100;
ct_epsilon_G(16,:)=(real_r_epsilon_G)*400;
ct_epsilon_G(17,:)=(MC_epsilon_G/MC_SS)*100;
ct_epsilon_G(18,:)=(PZ_epsilon_G/PZ_SS)*100;
ct_epsilon_G(19,:)=(U_epsilon_G/U_SS)*100;
ct_epsilon_G(20,:)=(CA_epsilon_G/CA_SS)*100;

ct_epsilon_ETA(1,:)=(A_epsilon_ETA/A_SS)*100;
ct_epsilon_ETA(2,:)=(C_epsilon_ETA/C_SS)*100;
ct_epsilon_ETA(3,:)=(G_epsilon_ETA/G_SS)*100;
ct_epsilon_ETA(4,:)=(I_epsilon_ETA/I_SS)*100;
ct_epsilon_ETA(5,:)=(K_epsilon_ETA/K_SS)*100;
ct_epsilon_ETA(6,:)=(L_epsilon_ETA/L_SS)*100;
ct_epsilon_ETA(7,:)=(M_epsilon_ETA/M_SS)*100;
ct_epsilon_ETA(8,:)=(R_epsilon_ETA)*.400;
ct_epsilon_ETA(9,:)=(W_epsilon_ETA/W_SS)*100;
ct_epsilon_ETA(10,:)=(Y_epsilon_ETA/Y_SS)*100;
ct_epsilon_ETA(11,:)=(Z_epsilon_ETA/Z_SS)*100;
ct_epsilon_ETA(12,:)=(PAI_epsilon_ETA)*.400;
ct_epsilon_ETA(13,:)=(ETA_epsilon_ETA)*.100;
ct_epsilon_ETA(14,:)=(PSI_epsilon_ETA/PSI_SS)*100;
ct_epsilon_ETA(15,:)=(W_epsilon_ETA/W_SS)*100;
ct_epsilon_ETA(16,:)=(real_r_epsilon_ETA)*400;
ct_epsilon_ETA(17,:)=(MC_epsilon_ETA/MC_SS)*100;
ct_epsilon_ETA(18,:)=(PZ_epsilon_ETA/PZ_SS)*100;
ct_epsilon_ETA(19,:)=(U_epsilon_ETA/U_SS)*100;
ct_epsilon_ETA(20,:)=(CA_epsilon_ETA/CA_SS)*100;

save('carbon_tax','ct_epsilon_A', 'ct_epsilon_G', 'ct_epsilon_ETA'); 
@#endif


//save results
@#if CT==0
cat_epsilon_A=[];
cat_epsilon_G=[];
cat_epsilon_ETA=[];

cat_epsilon_A(1,:)=(A_epsilon_A/A_SS)*100;
cat_epsilon_A(2,:)=(C_epsilon_A/C_SS)*100;
cat_epsilon_A(3,:)=(G_epsilon_A/G_SS)*100;
cat_epsilon_A(4,:)=(I_epsilon_A/I_SS)*100;
cat_epsilon_A(5,:)=(K_epsilon_A/K_SS)*100;
cat_epsilon_A(6,:)=(L_epsilon_A/L_SS)*100;
cat_epsilon_A(7,:)=(M_epsilon_A/M_SS)*100;
cat_epsilon_A(8,:)=(R_epsilon_A)*.400;
cat_epsilon_A(9,:)=(W_epsilon_A/W_SS)*100;
cat_epsilon_A(10,:)=(Y_epsilon_A/Y_SS)*100;
cat_epsilon_A(11,:)=(Z_epsilon_A/Z_SS)*100;
cat_epsilon_A(12,:)=(PAI_epsilon_A)*.400;
cat_epsilon_A(13,:)=(ETA_epsilon_A)*.100;
cat_epsilon_A(14,:)=(PSI_epsilon_A/PSI_SS)*100;
cat_epsilon_A(15,:)=(W_epsilon_A/W_SS)*100;
cat_epsilon_A(16,:)=(real_r_epsilon_A)*400;
cat_epsilon_A(17,:)=(MC_epsilon_A/MC_SS)*100;
cat_epsilon_A(18,:)=(PZ_epsilon_A/PZ_SS)*100;
cat_epsilon_A(19,:)=(U_epsilon_A/U_SS)*100;
cat_epsilon_A(20,:)=(CA_epsilon_A/CA_SS)*100;


cat_epsilon_G(1,:)=(A_epsilon_G/A_SS)*100;
cat_epsilon_G(2,:)=(C_epsilon_G/C_SS)*100;
cat_epsilon_G(3,:)=(G_epsilon_G/G_SS)*100;
cat_epsilon_G(4,:)=(I_epsilon_G/I_SS)*100;
cat_epsilon_G(5,:)=(K_epsilon_G/K_SS)*100;
cat_epsilon_G(6,:)=(L_epsilon_G/L_SS)*100;
cat_epsilon_G(7,:)=(M_epsilon_G/M_SS)*100;
cat_epsilon_G(8,:)=(R_epsilon_G)*.400;
cat_epsilon_G(9,:)=(W_epsilon_G/W_SS)*100;
cat_epsilon_G(10,:)=(Y_epsilon_G/Y_SS)*100;
cat_epsilon_G(11,:)=(Z_epsilon_G/Z_SS)*100;
cat_epsilon_G(12,:)=(PAI_epsilon_G)*.400;
cat_epsilon_G(13,:)=(ETA_epsilon_G)*.100;
cat_epsilon_G(14,:)=(PSI_epsilon_G/PSI_SS)*100;
cat_epsilon_G(15,:)=(W_epsilon_G/W_SS)*100;
cat_epsilon_G(16,:)=(real_r_epsilon_G)*400;
cat_epsilon_G(17,:)=(MC_epsilon_G/MC_SS)*100;
cat_epsilon_G(18,:)=(PZ_epsilon_G/PZ_SS)*100;
cat_epsilon_G(19,:)=(U_epsilon_G/U_SS)*100;
cat_epsilon_G(20,:)=(CA_epsilon_G/CA_SS)*100;

cat_epsilon_ETA(1,:)=(A_epsilon_ETA/A_SS)*100;
cat_epsilon_ETA(2,:)=(C_epsilon_ETA/C_SS)*100;
cat_epsilon_ETA(3,:)=(G_epsilon_ETA/G_SS)*100;
cat_epsilon_ETA(4,:)=(I_epsilon_ETA/I_SS)*100;
cat_epsilon_ETA(5,:)=(K_epsilon_ETA/K_SS)*100;
cat_epsilon_ETA(6,:)=(L_epsilon_ETA/L_SS)*100;
cat_epsilon_ETA(7,:)=(M_epsilon_ETA/M_SS)*100;
cat_epsilon_ETA(8,:)=(R_epsilon_ETA)*.400;
cat_epsilon_ETA(9,:)=(W_epsilon_ETA/W_SS)*100;
cat_epsilon_ETA(10,:)=(Y_epsilon_ETA/Y_SS)*100;
cat_epsilon_ETA(11,:)=(Z_epsilon_ETA/Z_SS)*100;
cat_epsilon_ETA(12,:)=(PAI_epsilon_ETA)*.400;
cat_epsilon_ETA(13,:)=(ETA_epsilon_ETA)*.100;
cat_epsilon_ETA(14,:)=(PSI_epsilon_ETA/PSI_SS)*100;
cat_epsilon_ETA(15,:)=(W_epsilon_ETA/W_SS)*100;
cat_epsilon_ETA(16,:)=(real_r_epsilon_ETA)*400;
cat_epsilon_ETA(17,:)=(MC_epsilon_ETA/MC_SS)*100;
cat_epsilon_ETA(18,:)=(PZ_epsilon_ETA/PZ_SS)*100;
cat_epsilon_ETA(19,:)=(U_epsilon_ETA/U_SS)*100;
cat_epsilon_ETA(20,:)=(CA_epsilon_ETA/CA_SS)*100;

save('cap_and_trade','cat_epsilon_A', 'cat_epsilon_G', 'cat_epsilon_ETA'); 
@#endif
