Rome, August 2024
Authors: Barbara Annicchiarico (Roma Tre University) and Fabio Di Dio (Sapienza University of Rome)

These Dynare codes implement our E-DSGE New Keynesian model with capital accumulation, as presented and calibrated in:

Annicchiarico, B. and Di Dio, F. (2015). "Environmental policy and macroeconomic dynamics in a New Keynesian model." *Journal of Environmental Economics and Management, 69*, 1-21.
https://www.sciencedirect.com/science/article/pii/S0095069614000850

- env_policy.mod: This script solves the model under two environmental policy scenarios—carbon tax (CT) and cap-and-trade (CAT). It also generates impulse response functions (IRFs) for technology and public spending shocks.

Note that the steady-state values for some variables are computed numerically using external function:

- ss_policy.m for the CT and CAT scenarios. The MATLAB Optimization Toolbox is required.

To see the results

- plot_IRFs.m: This script plots and compares IRFs to three canonical shocks under the two environmental policy scenarios

Feel free to use and modify these codes, but remember to acknowledge our work. Enjoy!

Barbara and Fabio













