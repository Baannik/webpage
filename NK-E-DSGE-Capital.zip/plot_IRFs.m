% Housekeeping.....
close all;
clear;

%Load Dynare results
load carbon_tax;
load cap_and_trade;

%create the time vector
time=[0:1:(length(cat_epsilon_G)-1)];

%Relevant variables' position
A=1;
C=2;
G=3;
I=4;
K=5;
L=6;
M=7;
R=8;
W=9;
Y=10;
Z=11;
PAI=12;
ETA=13;
PSI=14;
REAL_R=16;
MC=17;
PZ=18;
U=19;
CA=20;


%% Technology shock
figure(1)
sgtitle('IRFs to a 1\% Technology Shock','interpreter','latex')
subplot(2,5,1)
h=plot(time,ct_epsilon_A(Y,:),'b',time,cat_epsilon_A(Y,:),'r')
t1=title('Output')
set(t1,'FontSize',8,'interpreter','latex')
set(gca,'FontSize',8)
set(h,'LineWidth',1.5)
ylabel('$\%$', 'interpreter','latex')
subplot(2,5,2)
h=plot(time,ct_epsilon_A(C,:),'b',time,cat_epsilon_A(C,:),'r')
t1=title('Consumption')
set(t1,'FontSize',8,'interpreter','latex')
set(gca,'FontSize',8)
ylabel('$\%$', 'interpreter','latex')
subplot(2,5,3)
set(h,'LineWidth',1.5)
h=plot(time,ct_epsilon_A(I,:),'b',time,cat_epsilon_A(I,:),'r')
t1=title('Investment')
set(t1,'FontSize',8,'interpreter','latex')
set(gca,'FontSize',8)
set(h,'LineWidth',1.5)
ylabel('$\%$', 'interpreter','latex')
subplot(2,5,4)
h=plot(time,ct_epsilon_A(L,:),'b',time,cat_epsilon_A(L,:),'r')
t1=title('Labor')
set(t1,'FontSize',8,'interpreter','latex')
set(gca,'FontSize',8)
set(h,'LineWidth',1.5)
ylabel('$\%$', 'interpreter','latex')
subplot(2,5,5)
h=plot(time,ct_epsilon_A(MC,:),'b',time,cat_epsilon_A(MC,:),'r')
t1=title('Marginal Cost')
set(t1,'FontSize',8,'interpreter','latex')
set(gca,'FontSize',8)
set(h,'LineWidth',1.5)
ylabel('$\%$', 'interpreter','latex')
subplot(2,5,6)
h=plot(time,ct_epsilon_A(Z,:),'b')
t1=title('Emissions')
set(t1,'FontSize',8,'interpreter','latex')
set(gca,'FontSize',8)
set(h,'LineWidth',1.5)
ylabel('$\%$', 'interpreter','latex')
subplot(2,5,7)
h=plot(time,cat_epsilon_A(U,:),'r')
t1=title('Abatement Effort')
set(t1,'FontSize',8,'interpreter','latex')
set(gca,'FontSize',8)
set(h,'LineWidth',1.5)
ylabel('$\%$', 'interpreter','latex')
subplot(2,5,8)
h=plot(time,cat_epsilon_A(PZ,:),'r')
set(h,'LineWidth',1.5)
t1=title('Carbon Price')
set(t1,'FontSize',8,'interpreter','latex')
set(gca,'FontSize',8)
ylabel('$\%$', 'interpreter','latex')
subplot(2,5,9)
h=plot(time,ct_epsilon_A(PAI,:),'b',time,cat_epsilon_A(PAI,:),'r')
set(h,'LineWidth',1.5)
t1=title('Inflation')
set(t1,'FontSize',8,'interpreter','latex')
set(gca,'FontSize',8)
ylabel('p.p.', 'interpreter','latex')
subplot(2,5,10)
h=plot(time,ct_epsilon_A(R,:),'b',time,cat_epsilon_A(R,:),'r')
set(h,'LineWidth',1.5)
t1=title('Nominal Interest Rate')
set(t1,'FontSize',8,'interpreter','latex')
set(gca,'FontSize',8)
ylabel('p.p.', 'interpreter','latex')

lege=legend('carbon tax','cap-and-trade','Location','NorthEast')
set(lege,'FontSize',12,'interpreter','latex');





%% Public spending shock
figure(2)
sgtitle('IRFs to a 1\% Public Spending Shock','interpreter','latex')
subplot(2,5,1)
h=plot(time,ct_epsilon_G(Y,:),'b',time,cat_epsilon_G(Y,:),'r')
t1=title('Output')
set(t1,'FontSize',8,'interpreter','latex')
set(gca,'FontSize',8)
set(h,'LineWidth',1.5)
ylabel('$\%$', 'interpreter','latex')
subplot(2,5,2)
h=plot(time,ct_epsilon_G(C,:),'b',time,cat_epsilon_G(C,:),'r')
t1=title('Consumption')
set(t1,'FontSize',8,'interpreter','latex')
set(gca,'FontSize',8)
ylabel('$\%$', 'interpreter','latex')
subplot(2,5,3)
set(h,'LineWidth',1.5)
h=plot(time,ct_epsilon_G(I,:),'b',time,cat_epsilon_G(I,:),'r')
t1=title('Investment')
set(t1,'FontSize',8,'interpreter','latex')
set(gca,'FontSize',8)
set(h,'LineWidth',1.5)
ylabel('$\%$', 'interpreter','latex')
subplot(2,5,4)
h=plot(time,ct_epsilon_G(L,:),'b',time,cat_epsilon_G(L,:),'r')
t1=title('Labor')
set(t1,'FontSize',8,'interpreter','latex')
set(gca,'FontSize',8)
set(h,'LineWidth',1.5)
ylabel('$\%$', 'interpreter','latex')
subplot(2,5,5)
h=plot(time,ct_epsilon_G(MC,:),'b',time,cat_epsilon_G(MC,:),'r')
t1=title('Marginal Cost')
set(t1,'FontSize',8,'interpreter','latex')
set(gca,'FontSize',8)
set(h,'LineWidth',1.5)
ylabel('$\%$', 'interpreter','latex')
subplot(2,5,6)
h=plot(time,ct_epsilon_G(Z,:),'b')
t1=title('Emissions')
set(t1,'FontSize',8,'interpreter','latex')
set(gca,'FontSize',8)
set(h,'LineWidth',1.5)
ylabel('$\%$', 'interpreter','latex')
subplot(2,5,7)
h=plot(time,cat_epsilon_G(U,:),'r')
t1=title('Abatement Effort')
set(t1,'FontSize',8,'interpreter','latex')
set(gca,'FontSize',8)
set(h,'LineWidth',1.5)
ylabel('$\%$', 'interpreter','latex')
subplot(2,5,8)
h=plot(time,cat_epsilon_G(PZ,:),'r')
set(h,'LineWidth',1.5)
t1=title('Carbon Price')
set(t1,'FontSize',8,'interpreter','latex')
set(gca,'FontSize',8)
ylabel('$\%$', 'interpreter','latex')
subplot(2,5,9)
h=plot(time,ct_epsilon_G(PAI,:),'b',time,cat_epsilon_G(PAI,:),'r')
set(h,'LineWidth',1.5)
t1=title('Inflation')
set(t1,'FontSize',8,'interpreter','latex')
set(gca,'FontSize',8)
ylabel('p.p.', 'interpreter','latex')
subplot(2,5,10)
h=plot(time,ct_epsilon_G(R,:),'b',time,cat_epsilon_G(R,:),'r')
set(h,'LineWidth',1.5)
t1=title('Nominal Interest Rate')
set(t1,'FontSize',8,'interpreter','latex')
set(gca,'FontSize',8)
ylabel('p.p.', 'interpreter','latex')

lege=legend('carbon tax','cap-and-trade','Location','NorthEast')
set(lege,'FontSize',12,'interpreter','latex');





%% Monetary policy shock
figure(3)
sgtitle('IRFs to a 1\% Monetary Policy Shock','interpreter','latex')
subplot(2,5,1)
h=plot(time,ct_epsilon_ETA(Y,:),'b',time,cat_epsilon_ETA(Y,:),'r')
t1=title('Output')
set(t1,'FontSize',8,'interpreter','latex')
set(gca,'FontSize',8)
set(h,'LineWidth',1.5)
ylabel('$\%$', 'interpreter','latex')
subplot(2,5,2)
h=plot(time,ct_epsilon_ETA(C,:),'b',time,cat_epsilon_ETA(C,:),'r')
t1=title('Consumption')
set(t1,'FontSize',8,'interpreter','latex')
set(gca,'FontSize',8)
ylabel('$\%$', 'interpreter','latex')
subplot(2,5,3)
set(h,'LineWidth',1.5)
h=plot(time,ct_epsilon_ETA(I,:),'b',time,cat_epsilon_ETA(I,:),'r')
t1=title('Investment')
set(t1,'FontSize',8,'interpreter','latex')
set(gca,'FontSize',8)
set(h,'LineWidth',1.5)
ylabel('$\%$', 'interpreter','latex')
subplot(2,5,4)
h=plot(time,ct_epsilon_ETA(L,:),'b',time,cat_epsilon_ETA(L,:),'r')
t1=title('Labor')
set(t1,'FontSize',8,'interpreter','latex')
set(gca,'FontSize',8)
set(h,'LineWidth',1.5)
ylabel('$\%$', 'interpreter','latex')
subplot(2,5,5)
h=plot(time,ct_epsilon_ETA(MC,:),'b',time,cat_epsilon_ETA(MC,:),'r')
t1=title('Marginal Cost')
set(t1,'FontSize',8,'interpreter','latex')
set(gca,'FontSize',8)
set(h,'LineWidth',1.5)
ylabel('$\%$', 'interpreter','latex')
subplot(2,5,6)
h=plot(time,ct_epsilon_ETA(Z,:),'b')
t1=title('Emissions')
set(t1,'FontSize',8,'interpreter','latex')
set(gca,'FontSize',8)
set(h,'LineWidth',1.5)
ylabel('$\%$', 'interpreter','latex')
subplot(2,5,7)
h=plot(time,cat_epsilon_ETA(U,:),'r')
t1=title('Abatement Effort')
set(t1,'FontSize',8,'interpreter','latex')
set(gca,'FontSize',8)
set(h,'LineWidth',1.5)
ylabel('$\%$', 'interpreter','latex')
subplot(2,5,8)
h=plot(time,cat_epsilon_ETA(PZ,:),'r')
set(h,'LineWidth',1.5)
t1=title('Carbon Price')
set(t1,'FontSize',8,'interpreter','latex')
set(gca,'FontSize',8)
ylabel('$\%$', 'interpreter','latex')
subplot(2,5,9)
h=plot(time,ct_epsilon_ETA(PAI,:),'b',time,cat_epsilon_ETA(PAI,:),'r')
set(h,'LineWidth',1.5)
t1=title('Inflation')
set(t1,'FontSize',8,'interpreter','latex')
set(gca,'FontSize',8)
ylabel('p.p.', 'interpreter','latex')
subplot(2,5,10)
h=plot(time,ct_epsilon_ETA(R,:),'b',time,cat_epsilon_ETA(R,:),'r')
set(h,'LineWidth',1.5)
t1=title('Nominal Interest Rate')
set(t1,'FontSize',8,'interpreter','latex')
set(gca,'FontSize',8)
ylabel('p.p.', 'interpreter','latex')

lege=legend('carbon tax','cap-and-trade','Location','NorthEast')
set(lege,'FontSize',12,'interpreter','latex');




















